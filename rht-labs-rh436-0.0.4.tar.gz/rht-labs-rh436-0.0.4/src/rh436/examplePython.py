#
# Copyright (c) 2020 Red Hat Training <training@redhat.com>
#
# All rights reserved.
# No warranty, explicit or implied, provided.
#
# CHANGELOG
#   * Mon Oct 05 2020 Your Name <yname@redhat.com>
#   - original code

"""
Grading module for RH000 LAB_OR_GE_TITLE guided exercise (or lab).

This module either does start, grading, or finish for the
LAB_OR_GE_TITLE guided exercise (or lab).
"""

#########################################################################
#                   How to use this template:
#
# 1. Rename the file to SomethingRelatedToYourLab.py. Use WordCaps,
#    do not use dashes or underscores.
# 2. Adjust the CHANGELOG and docstring above.
# 3. Define the hosts that are used in this activity in the _targets list.
# 4. Rename the class. The name of the class must match the file name
#    (without the .py extension)
# 5. Remove the methods (start, finish, or grade) that your lab script
#    does not support.
# 6. Remove these "How to use this template" comments
#########################################################################

import os
import time
import pkg_resources

from labs.grading import Default
from labs.common import labtools, userinterface

# List of hosts involved in that module. Before doing anything,
# the module checks that they can be reached on the network
_targets = [
    "localhost",
    # "server-a",
    # "server-b",
    # "classroom",
    # "bastion",
]


# Change the class name to match your file name with WordCaps
class ExamplePython(Default):
    """
    Example Python lab script for GL006
    """
    __LAB__ = "example-python"

    # The following methods define which subcommands are supported
    # (start, grade, finish).
    # Remove the methods you do not need.

    def start(self):
        """
        Prepare the system for starting the lab
        """
        # The items dictionnary lists the tasks to run in order.
        # Each item describes a task. It is a dictionnary with the following
        # keys:
        #     label: Short, one line description of the task.
        #      task: Method or function to run. If not set, or set to None,
        #            nothing is executed for that step.
        #    failed: This is the result of the task execution. The function
        #            defined by the "task" key must set that status to True or
        #            False. This status is used to display the completion
        #            status of the task.
        #      msgs: List of error messages. Those messages may be set by the
        #            "task" function when the task fails. They are
        #            displayed to provide additional information to students.
        #            Each message in the list is a dictionnary with the key
        #            set to "text" and the text message as a value.
        #            For example:
        #              { "text": "The system cannot be reached"}
        items = [
            {
                "label": "Checking lab systems",
                "task": labtools.check_host_reachable,
                "hosts": _targets,
                "fatal": True,
            },
            {
                "label": "API Reachable",
                "task": self._start_check_api,
                "fatal": True,
            },
            {
                "label": "Cluster Ready",
                "task": self._start_check_cluster_ready,
                "fatal": True,
            },
            {
                "label": "Configuration deployed",
                "task": self._start_conf_deployed,
            },
            {
                "label": "Task that succeeds",
                "task": self._start_sample_success_task,
            },
            {
                "label": "Task that fails",
                "task": self._start_sample_failure_task,
            },
            {
                "label": "Do nothing task that always succeeds",
                "failed": False,
            },
            {
                "label": "Do nothing task that always fails",
                "failed": True,
            },
        ]
        userinterface.Console(items).run_items(action="Starting")

    def grade(self):
        """
        Perform evaluation steps on the system
        """
        items = [
            {
                "label": "Checking lab systems",
                "task": labtools.check_host_reachable,
                "hosts": _targets,
                "fatal": True,
            },
            {
                "label": "Configuration file exists",
                "task": self._grade_check_conf,
            },
            {
                "label": "Sample test",
                "task": self._grade_test,
            }
        ]
        ui = userinterface.Console(items)
        ui.run_items(action="Grading")
        ui.report_grade()

    def finish(self):
        """
        Perform post-lab cleanup
        """
        items = [
            {
                "label": "Checking lab systems",
                "task": labtools.check_host_reachable,
                "hosts": _targets,
                "fatal": True,
            },
            {
                "label": "Remove student's working directory",
                "task": self._finish_workdir,
            },
        ]
        userinterface.Console(items).run_items(action="Finishing")

    # Start tasks

    def _start_check_api(self, item):
        """
        Execute a task to prepare the system for the lab.
        """
        # The method MUST set ``item["failed"]`` to ``False`` on success or
        # ``True`` on error.
        # Additionally, on error, the method can provide messages
        # through the ``item["msgs"]`` list. Each item in this list is a
        # dictionnary with the key set to "text" and the message as the value.
        # For example:
        #    {"text": "The file is missing on the system"}
        #
        # Those messages are displayed to the student.
        #
        # If the method returns 0 (or a value evaluated as False), then the
        # lab module continues with the next task unless the item["fatal"]
        # is set to True.
        #
        # When `failed` is set to True, if the task fails, other tasks will
        # not be executed.
        #
        # Otherwise, the lab framework immediately stops.
        #
        # :param item: Task to process.
        # :type item: dict
        #
        # :returns: 0 for the lab module to carry on with the next step, or
        #          another value for the lab module to stop immediately.

        item["failed"] = False
        time.sleep(2.5)

    def _start_check_cluster_ready(self, item):
        item["failed"] = False
        time.sleep(2)

    def _start_conf_deployed(self, item):
        """
        Create a sample file in ~/SKU/lab_name
        """
        lab_name = type(self).__name__
        student_working_dir = os.path.join(
            labtools.get_sku_path(),
            lab_name
        )

        # Create the ~/SKU/lab_name directory with a wrapper function
        mkdir_result = labtools.mkdir(student_working_dir)
        if mkdir_result["failed"]:
            item["failed"] = True
            item["msgs"] = [{"text": "Directory could not be created"}]
            return

        # Create a test_file inside ~/SKU/lab_name with native Python code
        src = os.path.join(
            pkg_resources.resource_filename(__name__, "materials"),
            lab_name,
            "test.conf",
        )
        cp_result = labtools.cp(src, lab_name)
        if cp_result["failed"]:
            item["failed"] = True
            item["msgs"] = [{"text": "File could not be copied"}]
            return

    def _start_sample_success_task(self, item):
        item["failed"] = False
        time.sleep(1)

    def _start_sample_failure_task(self, item):
        item["failed"] = True
        item["msgs"] = [
            {"text": "Sample explanation of failure"},
            {"text": "Further explanation would go here"},
        ]
        time.sleep(1)

    # Grading tasks

    def _grade_check_conf(self, item):
        """
        Check if test_file exists on ~/SKU/lab_name
        """
        lab_name = type(self).__name__
        file_path = os.path.join(
            labtools.get_sku_path(),
            lab_name,
            "test.conf"
        )
        if not os.path.exists(file_path):
            item["failed"] = True
            item["msgs"] = [{"text": "File does not exist"}]

    def _grade_test(self, item):
        item["failed"] = False
        time.sleep(3)

    # Finish tasks

    def _finish_workdir(self, item):
        """
        Remove student's working directory ~/SKU/lab_name
        """
        lab_name = type(self).__name__
        # Removing the ~/SKU/lab_name directory
        if not labtools.rmdir(lab_name, recursive=True):
            item["failed"] = True
            item["msgs"] = [{"text": "Directory could not be removed"}]
            return

        # Note: This section is commented out because we should not
        # remove the ~/SKU directory
        # # Remove the ~/SKU directory
        # try:
        #     shutil.rmtree(labtools.get_sku_path())
        # except OSError as e:
        #     item["failed"] = True
        #     item["msgs"] = [{"text": e}]
        # else:
        #     item["failed"] = False
