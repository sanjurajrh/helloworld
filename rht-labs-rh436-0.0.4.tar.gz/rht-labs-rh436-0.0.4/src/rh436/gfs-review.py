#
# Copyright (c) 2021 Red Hat Training <training@redhat.com>
#
# All rights reserved.
# No warranty, explicit or implied, provided.
#
# CHANGELOG
#   * Fri Feb 05 2021 Your Name <yname@redhat.com>
#   - original code

from labs.grading import AutoPlay


class AutoPlay11_3(AutoPlay):
    __LAB__ = "gfs-review"
