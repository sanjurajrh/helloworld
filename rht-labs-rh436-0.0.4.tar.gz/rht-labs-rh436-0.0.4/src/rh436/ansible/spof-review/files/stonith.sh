#!/bin/bash

pcs stonith create fence_classroom fence_rh436 ipaddr=192.168.0.100 login=admin passwd=password power_timeout=180 pcmk_host_map="nodeb.private.example.com:2;nodec.private.example.com:3;noded.private.example.com:4"
