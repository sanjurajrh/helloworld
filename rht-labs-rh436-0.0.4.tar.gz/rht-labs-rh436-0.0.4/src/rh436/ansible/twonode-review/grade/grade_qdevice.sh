#!/bin/bash
#
# Copyright 2021 Red Hat, Inc.
#

# Ansible always deploys the tool box in /tmp
source /tmp/gradingtool.shlib

TMP_FILE=$(mktemp)


pad "The quorum device package is installed"
rpm -q corosync-qdevice
print_RET


pad "The quorum device is configured for nodea.san01.example.com"
pcs quorum config &> "${TMP_FILE}"
grep -Fq -e nodea.san01.example.com -e 192.168.1.10 "${TMP_FILE}"
print_RET


pad "The quorum device is using the ffsplit algorithm"
grep -Fq ffsplit "${TMP_FILE}"
print_RET


rm -rf "${TMP_FILE}"

# Print the result as a JSON structure
result2json
