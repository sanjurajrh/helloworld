#!/bin/bash
#
# Copyright 2021 Red Hat, Inc.
#

# Ansible always deploys the tool box in /tmp
source /tmp/gradingtool.shlib

TMP_FILE=$(mktemp)


pad "The cluster is running"
pcs status --full &> "${TMP_FILE}"
print_RET "FAIL: cannot get the status of the cluster. Maybe it is not running"


pad "The cluster is named cluster2"
grep -qFw cluster2 "${TMP_FILE}"
print_RET


pad "The cluster is online on nodec"
grep -qE "nodec.private.example.com:\s+Online" "${TMP_FILE}"
print_RET "FAIL: the cluster is not active on nodec.private.example.com"


pad "The cluster is online on noded"
grep -qE "noded.private.example.com:\s+Online" "${TMP_FILE}"
print_RET "FAIL: the cluster is not active on noded.private.example.com"


pad "The STONITH timeout is set to 180 seconds"
pcs property show stonith-timeout | grep -Fq 180s
print_RET

rm -rf "${TMP_FILE}"

# Print the result as a JSON structure
result2json
