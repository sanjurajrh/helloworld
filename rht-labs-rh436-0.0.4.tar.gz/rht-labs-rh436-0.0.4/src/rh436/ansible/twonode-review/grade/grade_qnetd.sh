#!/bin/bash
#
# Copyright 2021 Red Hat, Inc.
#

# Ansible always deploys the tool box in /tmp
source /tmp/gradingtool.shlib


pad "The firewall is opened for HA"
firewall-cmd --list-services | grep -Fq high-availability
print_RET


pad "The cluster packages are installed"
rpm -q pcs
print_RET "FAIL: the Pacemaker system daemon package is not installed"


pad "The quorum device package is installed"
rpm -q corosync-qnetd
print_RET


pad "The Pacemaker system daemon is enabled"
systemctl is-enabled pcsd
print_RET "FAIL: the Pacemaker system daemon is not enabled in systemd"


pad "The Pacemaker system daemon is running"
systemctl is-active pcsd
print_RET "FAIL: the Pacemaker systemd service is not running"


pad "The quorum device daemon is enabled"
systemctl is-enabled corosync-qnetd
print_RET


pad "The quorum device daemon is running"
systemctl is-active corosync-qnetd
print_RET


pad "The quorum device is configured and running"
pcs qdevice status net
print_RET


# Print the result as a JSON structure
result2json
