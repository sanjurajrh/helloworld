#!/bin/bash

pcs stonith create fence_nodec fence_ipmilan pcmk_host_list=nodec.private.example.com ip=192.168.0.103 username=admin password=password lanplus=1 power_timeout=180
pcs stonith create fence_noded fence_ipmilan pcmk_host_list=noded.private.example.com ip=192.168.0.104 username=admin password=password lanplus=1 power_timeout=180
