#!/bin/bash
#
# Copyright 2021 Red Hat, Inc.
#

# Ansible always deploys the tool box in /tmp
source /tmp/gradingtool.shlib


pad "The /dev/mapper/disk1 device has an ext4 file system"
lsblk -n -o FSTYPE /dev/mapper/disk1 | grep -qw ext4
print_RET "FAIL: cannot find the ext4 file system"


# Print the result as a JSON structure
result2json
