#!/bin/bash
#
# Copyright 2021 Red Hat, Inc.
#

# Ansible always deploys the tool box in /tmp
source /tmp/gradingtool.shlib


pad "The iSCSI initiator package is installed"
rpm -q iscsi-initiator-utils
print_RET "FAIL: the iSCSI initiator is not installed"


SHORT_HOSTNAME=$(hostname -s)
pad "The initiator IQN is iqn.2014-06.com.example:${SHORT_HOSTNAME}"
grep -Fq "iqn.2014-06.com.example:${SHORT_HOSTNAME}" /etc/iscsi/initiatorname.iscsi
print_RET "FAIL: the IQN is wrong in the initiator configuration file"


pad "The initiator is using the 192.168.1.15:3260 portal"
TMP_FILE=$(mktemp)
iscsiadm -m session -P 3 > "${TMP_FILE}"
grep -iq "Persistent Portal:.*192.168.1.15:3260" "${TMP_FILE}"
print_RET "FAIL: the portal is not 192.168.1.15:3260"


pad "The initiator is using the 192.168.2.15:3260 portal"
grep -iq "Persistent Portal:.*192.168.2.15:3260" "${TMP_FILE}"
print_RET "FAIL: the portal is not 192.168.2.15:3260"


pad "The initiator is connected to iqn.2014-06.com.example:store1"
grep -qFw "iqn.2014-06.com.example:store1" "${TMP_FILE}"
print_RET "FAIL: the initiator is not using the correct target"


pad "The package for multipath is installed"
rpm -q device-mapper-multipath
print_RET "FAIL: the package is not installed"


# Retrieve the iSCSI device (sda, sdb, ...) and the associated WWID
DISK=$(awk '/Attached scsi disk/ { print $4; exit; }' "${TMP_FILE}")
if [ -n "${DISK}" ]
then
    WWID=$(udevadm info "/dev/${DISK}" | awk -F= '/ID_SERIAL=/ { print $2 }')
else
    WWID=""
fi


pad "The disk WWWID is set in the multipath configuration file"
grep -Eiq "wwid\s+${WWID}" /etc/multipath.conf
print_RET "FAIL: the WWID is not correctly defined in the configuration file"


pad "The disk1 alias is set in the multipath configuration file"
grep -Eiq "alias\s+disk1" /etc/multipath.conf
print_RET "FAIL: the alias is not correctly defined in the configuration file"


pad "The multipath daemon is enabled"
systemctl is-enabled multipathd
print_RET "FAIL: the daemon is not enabled in systemd"


pad "The multipath daemon is running"
systemctl is-active multipathd
print_RET "FAIL: the multipath daemon systemd service is not running"


rm -rf "${TMP_FILE}"

# Print the result as a JSON structure
result2json
