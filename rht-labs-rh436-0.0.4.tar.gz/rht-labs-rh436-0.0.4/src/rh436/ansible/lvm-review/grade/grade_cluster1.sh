#!/bin/bash
#
# Copyright 2021 Red Hat, Inc.
#

# Ansible always deploys the tool box in /tmp
source /tmp/gradingtool.shlib


pad "Checking the PV exists"
pvs | grep -qF /dev/mapper/disk1
print_RET "FAIL: the /dev/mapper/disk1 physical volume is missing"


pad "Checking the data VG exists"
vgs | grep -wqFi data
print_RET "FAIL: the data volume group is missing"


pad "Checking the db LV exists"
lvs | grep -wqFi db
print_RET "FAIL: the db logical volume is missing"


pad "Checking the LV size"
lvs | grep -wqi "2\.[0-9]*g"
print_RET "FAIL: the size of the db logical volume is not 2 GiB"


pad "Checking the ext4 file system"
lsblk -n -o FSTYPE /dev/mapper/data-db | grep -wqF ext4
print_RET "FAIL: /dev/data/db does not have an ext4 file system"


pad "Checking the lv cluster resource exists"
TMP_FILE=$(mktemp)
pcs resource config > "${TMP_FILE}"
grep -Eqi "Resource:\s+lv\s" "${TMP_FILE}"
print_RET "FAIL: cannot find the lv resource"


pad "Checking the lv resource activates the data VG"
grep -wqFi vgname=data "${TMP_FILE}"
print_RET "FAIL: the resource does not have the VG name set to data"


pad "Checking the lv resource sets the VG activation mode"
grep -wqFi vg_access_mode=system_id "${TMP_FILE}"
print_RET "FAIL: the resource does not use LVM system ID for activating the VG"


pad "Checking the halvm resource group exists"
grep -Eqi "Group:\s+halvm" "${TMP_FILE}"
print_RET "FAIL: cannot find the halvm resource group"


pad "Checking the ext4fs cluster resource exists"
grep -Eqi "Resource:\s+ext4fs\s" "${TMP_FILE}"
print_RET "FAIL: cannot find the ext4fs resource"


pad "Checking the ext4fs resource mounts /var/lib/db"
grep -qFi directory=/var/lib/db "${TMP_FILE}"
print_RET "FAIL: the resource does not mount the directory"


pad "Checking the ext4fs resource uses the ext4 type"
grep -wqFi fstype=ext4 "${TMP_FILE}"
print_RET "FAIL: the file system type is not set to ext4"


pad "Checking the ext4fs resource uses the LV device"
grep -wqEi "device=.*data[/-]db" "${TMP_FILE}"
print_RET "FAIL: the device is not /dev/data/db"


rm -rf "${TMP_FILE}"

# Print the result as a JSON structure
result2json
