#!/bin/bash
#
# Copyright 2021 Red Hat, Inc.
#

# Ansible always deploys the tool box in /tmp
source /tmp/gradingtool.shlib

pad "Checking the webdata VG is registered with lvmlockd"
lvmlockctl -i | grep -Fqwi webdata
print_RET "FAIL: the VG is not registered"

# Print the result as a JSON structure
result2json
