#!/bin/bash
#
# Copyright 2021 Red Hat, Inc.
#

# Ansible always deploys the tool box in /tmp
source /tmp/gradingtool.shlib

pad "Checking the RPM packages are installed"
rpm -q dlm && rpm -q lvm2-lockd
print_RET "FAIL: at least one package is missing"

# Print the result as a JSON structure
result2json
