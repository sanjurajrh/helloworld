#!/bin/bash
#
# Copyright 2021 Red Hat, Inc.
#

# Ansible always deploys the tool box in /tmp
source /tmp/gradingtool.shlib

pad "Checking LVM system ID is set"
lvm systemid | grep -wq $(hostname)
print_RET "FAIL: the lvm systemid command does not return the host name"

# Print the result as a JSON structure
result2json
