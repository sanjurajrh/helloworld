#!/bin/bash
#
# Copyright 2021 Red Hat, Inc.
#

# Ansible always deploys the tool box in /tmp
source /tmp/gradingtool.shlib


pad "Checking the dlm cluster resource exists"
TMP_FILE=$(mktemp)
pcs resource config > "${TMP_FILE}"
grep -Eqi "Resource:\s+dlm\s" "${TMP_FILE}"
print_RET "FAIL: cannot find the dlm resource"


pad "Checking the dlm resource uses the controld agent"
grep -wqEi "dlm\s.*type=controld" "${TMP_FILE}"
print_RET "FAIL: the resource does not use the correct agent"


pad "Checking the locking resource group exists"
grep -Eqi "Group:\s+locking" "${TMP_FILE}"
print_RET "FAIL: cannot find the locking resource group"


pad "Checking the locking resource group is cloned"
grep -Eqi "Clone:\s+locking-clone" "${TMP_FILE}"
print_RET "FAIL: the resource group is not cloned"


pad "Checking the lvmlockd cluster resource exists"
grep -Eqi "Resource:\s+lvmlockd\s" "${TMP_FILE}"
print_RET "FAIL: cannot find the lvmlockd resource"


pad "Checking the lvmlockd resource uses the lvmlockd agent"
grep -wqEi "lvmlockd\s.*type=lvmlockd" "${TMP_FILE}"
print_RET "FAIL: the resource does not use the correct agent"


pad "Checking the PV exists"
pvs | grep -qF /dev/mapper/disk2
print_RET "FAIL: the /dev/mapper/disk2 physical volume is missing"


pad "Checking the webdata VG exists"
vgs | grep -wqFi webdata
print_RET "FAIL: the webdata volume group is missing"


pad "Checking the VG is shared"
vgs --noheadings -o vg_shared webdata | grep -wqFi shared
print_RET "FAIL: the volume group does not have the shared flag"


pad "Checking the logs LV exists"
lvs | grep -wqFi logs
print_RET "FAIL: the logs logical volume is missing"


pad "Checking the LV size"
lvs | grep -wqi "3\.[0-9]*g"
print_RET "FAIL: the size of the logs logical volume is not 3 GiB"


pad "Checking the lv1 cluster resource exists"
grep -Eqi "Resource:\s+lv1\s" "${TMP_FILE}"
print_RET "FAIL: cannot find the lv1 resource"


pad "Checking the lv1 resource has the correct activation mode"
grep -wqFi activation_mode=shared "${TMP_FILE}"
print_RET "FAIL: the resource does not use the correct mode"


pad "Checking the lv1 resource is configured for the webdata VG"
grep -wqFi vgname=webdata "${TMP_FILE}"
print_RET "FAIL: the resource does not target the correct VG"


pad "Checking the lv1 resource is configured for the logs LV"
grep -wqFi lvname=logs "${TMP_FILE}"
print_RET "FAIL: the resource does not target the correct LV"


pad "Checking the lv1 resource is configured for lvmlockd"
grep -wqFi vg_access_mode=lvmlockd "${TMP_FILE}"
print_RET "FAIL: the resource is not configured for the lvmlockd access mode"


pad "Checking the sharedVG resource group exists"
grep -Eqi "Group:\s+sharedVG" "${TMP_FILE}"
print_RET "FAIL: cannot find the sharedVG resource group"


pad "Checking the sharedVG resource group is cloned"
grep -Eqi "Clone:\s+sharedVG-clone" "${TMP_FILE}"
print_RET "FAIL: the resource group is not cloned"


pad "Checking ordering constraint"
pcs constraint > "${TMP_FILE}"
grep -Fqi "start locking-clone then start sharedVG-clone" "${TMP_FILE}"
print_RET "FAIL: the constraint 'locking-clone then sharedVG-clone' is missing"


pad "Checking colocation constraint"
grep -Fqi -e "sharedVG-clone with locking-clone" -e "locking-clone with sharedVG-clone" "${TMP_FILE}"
print_RET "FAIL: the constraint 'sharedVG-clone with locking-clone' is missing"


rm -rf "${TMP_FILE}"

# Print the result as a JSON structure
result2json
