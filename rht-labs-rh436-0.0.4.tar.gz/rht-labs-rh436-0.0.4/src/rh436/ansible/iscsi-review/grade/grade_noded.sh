#!/bin/bash
#
# Copyright 2021 Red Hat, Inc.
#

# Ansible always deploys the tool box in /tmp
source /tmp/gradingtool.shlib


pad "The iSCSI initiator package is installed"
rpm -q iscsi-initiator-utils
print_RET "FAIL: the iSCSI initiator is not installed"


pad "The initiator IQN is iqn.2014-06.com.example:noded"
grep -Fq iqn.2014-06.com.example:noded /etc/iscsi/initiatorname.iscsi
print_RET "FAIL: the IQN is wrong in the initiator configuration file"


pad "The initiator is using the 192.168.2.15:3260 portal"
TMP_FILE=$(mktemp)
iscsiadm -m session -P 3 > "${TMP_FILE}"
grep -iq "Persistent Portal:.*192.168.2.15:3260" "${TMP_FILE}"
print_RET "FAIL: the portal is not 192.168.2.15:3260"


pad "The initiator is connected to iqn.2014-06.com.example:store1"
grep -qFw "iqn.2014-06.com.example:store1" "${TMP_FILE}"
print_RET "FAIL: the initiator is not using the correct target"


pad "The /iscsidisk directory exists"
test -d /iscsidisk
print_RET "FAIL: /iscsidisk does not exist or is not a directory"


pad "The file system is mounted on /iscsidisk"
DEVICE=$(awk '/Attached scsi disk/ { print $4 }' "${TMP_FILE}")
if [ -z "${DEVICE}" ]
then
    DEVICE='unkwonw'
fi
df /iscsidisk | grep -qw ${DEVICE}
print_RET "FAIL: ${DEVICE} is not mounted under /iscsidisk"


pad "The file system is declared in /etc/fstab"
grep -w /iscsidisk /etc/fstab > "${TMP_FILE}"
print_RET "FAIL: /iscsidisk is missing in the file"


pad "The correct mount option is used in /etc/fstab"
grep -qw _netdev "${TMP_FILE}"
print_RET "FAIL: the network device option is missing"


pad "The correct file system type is used in /etc/fstab"
grep -qw ext4 "${TMP_FILE}"
print_RET "FAIL: the type is wrong"


rm -rf "${TMP_FILE}"

# Print the result as a JSON structure
result2json
