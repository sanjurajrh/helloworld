ha_create
=========

This role creates a Red Hat High Availability Add-On cluster.


Requirements
------------

The cluster nodes must be subscribed to the following repository for the role to work:

* rhel-8-for-x86_64-baseos-rpms
* rhel-8-for-x86_64-appstream-rpms
* rhel-8-for-x86_64-resilientstorage-rpms
* rhel-8-for-x86_64-highavailability-rpms


Role Variables
--------------

The role accepts the following variables:

* `ha_create_cluster_name`: The name of the cluster to create.
  `cluster1` by default.
* `ha_create_password`: The password to set for the `hacluster` user account.
  `redhat` by default.
* `ha_create_nodes`: The list of cluster nodes.
  The node names must resolvable.
  By default, the list is built from all the hosts in the play.


Dependencies
------------

None


Example Playbook
----------------

```yaml
---
- name: Creating the cluster
  hosts: node[a-c]
  become: yes
  gather_facts: no

  tasks:
    - include_role:
        name: ha_create
      vars:
        ha_create_nodes:
          - nodea.private.example.com
          - nodeb.private.example.com
          - nodec.private.example.com
...
```

The `tests/` directory provides an additional example.


License
-------

GPL 3.0 or later.
