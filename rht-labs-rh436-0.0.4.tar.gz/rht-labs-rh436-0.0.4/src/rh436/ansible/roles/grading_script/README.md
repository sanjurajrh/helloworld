grading_script
==============

This role deploys and runs a grading script on the targeted hosts.
The script must be provided using the `grading_script_path` variable.
On the targeted host, the script is run as an Ansible facts script.
As a consequence, it must write a JSON structure on its standard output.

The following example provides the expected structure for this output.

```json
{
  "counters":{
    "pass":2,
    "fail":2
  },
  "results":[
    {
      "name":"Required package is installed",
      "msg":""
      "pass":true
    },
    {
      "name":"File system defined in /etc/fstab",
      "msg":"The /data1 file system is not in the /etc/fstab file"
      "pass":false
    },
    {
      "name":"The process is running",
      "msg":"The expected process is not running on the system"
      "pass":false
    },
    {
      "name":"The command runs successfully",
      "msg":""
      "pass":true
    }
  ]
}
```

The role also deploys a shell script tool box in `/tmp/gradingtool.shlib` on the targeted hosts.
That tool box provides functions to simplify grading shell script development.

The following script example uses that tool box:

```bash
#!/bin/bash

# Ansible always deploys the tool box in /tmp
source /tmp/gradingtool.shlib


pad "Required package is installed"
if rpm -q httpd
then
  print_PASS
else
  print_FAIL "The httpd package has not been installed"
fi


pad "File system defined in /etc/fstab"
grep /data1 /etc/fstab
# The  print_RET() function is a shortcut for the
# if ... then print_PASS else print_FAIL construct.
# It uses the return code of the preceding command to figure out
# the status of the task.
print_RET "The /data1 file system is not in the /etc/fstab file"


pad "The process is running"
echo "Simulate checking process"
print_FAIL "The expected process is not running on the system"


pad "The command runs successfully"
echo "When not using print_PASS, print_FAIL, nor print_RET,"
echo "the result is PASS by default"


# Print the result as a JSON structure
result2json
```


Requirements
------------

None


Role Variables
--------------

The role accept the `grading_script_path` variable.
That variable specifies the grading script to run as an Ansible fact script on the targeted host.


Dependencies
------------

None


Example Playbook
----------------

```yaml
---
- name: Grading exercise on nodea
  hosts: nodea
  become: yes
  gather_facts: no

  tasks:
    - name: Grading student's work
      include_role:
        name: grading_script
      vars:
        grading_script_path: grade_20_1_nodea.sh
...
```

The `tests/` directory provides an additional example.


License
-------

GPL 3.0 or later.
