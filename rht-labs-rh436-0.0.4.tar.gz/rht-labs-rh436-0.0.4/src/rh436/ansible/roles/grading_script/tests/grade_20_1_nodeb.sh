#!/bin/bash

# Include the tool box. The Ansible role automatically deploys that file in /tmp
source /tmp/gradingtool.shlib


pad "The required package is installed"
if rpm -q gzip
then
    print_PASS
else
    print_FAIL "The gzip package has not been installed"
fi


pad "The file system is defined in /etc/fstab"
grep /data1 /etc/fstab
# The  print_RET() function is a shortcut for the
# "if ... then print_PASS else print_FAIL" construct.
# It uses the return code of the preceding command to figure out
# the status of the task.
print_RET "The /data1 file system is not in the /etc/fstab file"


pad "The process is running"
echo "Simulate checking process"
print_FAIL "The expected process is not running on the system"


pad "The command runs successfully"
echo "When not using print_PASS, print_FAIL, nor print_RET,"
echo "the result is PASS by default"


result2json
