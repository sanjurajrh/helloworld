#!/bin/bash

# Include the tool box. The Ansible role automatically deploys that file in /tmp
source /tmp/gradingtool.shlib


pad "The required package is installed"
if rpm -q gzip
then
    print_PASS
else
    print_FAIL "The gzip package has not been installed"
fi


pad "The process is running"
ps -C chronyd
# The  print_RET() function is a shortcut for the
# "if ... then print_PASS else print_FAIL" construct.
# It uses the return code of the preceding command to figure out
# the status of the task.
print_RET "The chronyd process is not running on the system"


pad "The service is enabled"
systemctl is-enabled chronyd
print_RET "The chronyd service is not enabled in systemd"


result2json
