nfs_share_destroy
================

This role removes the NFS sharing of a directory.


Requirements
------------

None


Role Variables
--------------

The role accepts the `nfs_share_destroy_shared_dir` variable to specify the shared directory to delete.
By default the variable is not set so that the shared directory is preserved.

**Warning**: If you set the `nfs_share_destroy_shared_dir` variable, then the specified directory is recursively removed.


Dependencies
------------

None


Example Playbook
----------------

```yaml
---
- name: Stop NFS sharing the directory
  hosts: storage
  become: yes
  gather_facts: no

  tasks:
    - include_role:
        name: nfs_share_destroy
      vars:
        nfs_share_destroy_shared_dir: /srv/shared
...
```

The `tests/` directory provides an additional example.


License
-------

GPL 3.0 or later.
