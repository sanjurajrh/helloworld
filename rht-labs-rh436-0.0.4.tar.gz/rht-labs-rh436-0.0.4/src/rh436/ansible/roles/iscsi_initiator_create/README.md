iscsi_initiator_create
======================

This role connects an iSCSI initiator to a target.
If the target is available through multiple portals (IP), the role can connect to all those portals.


Requirements
------------

None


Role Variables
--------------

The role accepts the following variables:

* `iscsi_initiator_create_iqn`: The IQN to set for the initiator.
  `iqn.2014-06.com.example:<short_hostname>` by default.
* `iscsi_initiator_create_target_iqn`: The IQN of the target.
  `iqn.2014-06.com.example:storage` by default.
* `iscsi_initiator_create_portals`: The list of IP addresses of the portal.
  By default, 192.168.1.15 and 192.168.2.15.


Dependencies
------------

None


Example Playbook
----------------

```yaml
---
- name: Configuring the iSCSI initiator
  hosts: nodes
  become: yes
  gather_facts: no

  tasks:
    - include_role:
        name: iscsi_initiator_create
      vars:
        iscsi_initiator_create_target_iqn: iqn.2014-06.com.example:disk1
        iscsi_initiator_create_portals:
          - 192.168.1.15
...
```

The `tests/` directory provides an additional example.


License
-------

GPL 3.0 or later.
