workingdir
==========

This role creates a working directory for the student in `/home/student/labs/<ID>/`.
You define the `<ID>` sub directory using the `workingdir_exercise` variable.
This is usually a directory dedicated for the exercise where the preparation script deploys playbooks and other artifacts that the student uses during the exercise.

If the working directory already exists, then it is saved (the date/time is added at the end), and a fresh directory is created. This way, if the student previously completed the exercise and is redoing it, then their previous work is preserved.

If the `workingdir_copy_cfg` variable is `true` (the default), the `inventory` and `ansible.cfg` files are also copied in the working directory.


Requirements
------------

None


Role Variables
--------------

The role accepts the following variables:

* `workingdir_exercise`: The name of the sub directory under `/home/student/labs/`. This is usually the name of the exercise (`lab_02_3` for example).
  `lab_01_1` by default.
* `workingdir_copy_cfg`: Whether the `inventory` and `ansible.cfg` files must be deployed in the working directory.
  By default, `workingdir_copy_cfg` is set to `yes` so that the files are deployed.


Dependencies
------------

None


Example Playbook
----------------

```yaml
---
- name: Creating the working directory for the exercise
  hosts: workstation
  become: yes
  gather_facts: no

  tasks:
    - include_role:
        name: workingdir
      vars:
        workingdir_exercise: lab_03_1
        workingdir_copy_cfg: no
...
```

The `tests/` directory provides an additional example.


License
-------

GPL 3.0 or later.
