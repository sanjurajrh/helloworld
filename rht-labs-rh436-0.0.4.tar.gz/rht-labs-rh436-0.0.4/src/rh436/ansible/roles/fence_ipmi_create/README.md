fence_ipmi_create
=================

This role adds an IPMI fencing resource to an existing Red Hat High Availability Add-On cluster.

You need to call that role once for each cluster node to create the fence device for all the nodes.


Requirements
------------

* The cluster must be running. See the `ha_create` role to create that cluster.
* Ansible Facts must be available (set `gather_facts` to `yes`)


Role Variables
--------------

The role accepts the following variables:

* `fence_ipmi_create_id`: The cluster resource name.
  `fence_<short_hostname>` by default.
* `fence_ipmi_create_node`: The name of the cluster node that this device can fence.
  The system host name by default.
* `fence_ipmi_create_ip`: The IP address of the BMC device.
  By default, 192.168.0.10X, where X is the last digit of the current IP + 1
  (for example, if the IP address is 172.25.250.11, then the default BMC address is 192.168.0.102)
* `fence_ipmi_create_login`: The login name to access the fence device.
  `admin` by default.
* `fence_ipmi_create_password`: The password associated with the login.
  `password` by default.
* `fence_ipmi_create_timeout`: Time to wait before considering that the fence operation has failed.
  180 seconds by default.


Dependencies
------------

None


Example Playbook
----------------

```yaml
---
- name: Creating the fence device resources
  hosts: nodes
  become: yes
  gather_facts: yes

  tasks:
    # Creating the cluster (requirement)
    - include_role:
        name: ha_create
      vars:
        ha_create_nodes:
          - nodea.private.example.com
          - nodeb.private.example.com
          - nodec.private.example.com
          - noded.private.example.com

    - include_role:
        name: fence_ipmi_create
      vars:
        fence_ipmi_create_id: "{{ item['id'] }}"
        fence_ipmi_create_node: "{{ item['node'] }}"
        fence_ipmi_create_ip: "{{ item['ip'] }}"
      loop:
        - id: fence_nodea
          node: nodea.private.example.com
          ip: 192.168.0.101
        - id: fence_nodeb
          node: nodeb.private.example.com
          ip: 192.168.0.102
        - id: fence_nodec
          node: nodec.private.example.com
          ip: 192.168.0.103
        - id: fence_noded
          node: noded.private.example.com
          ip: 192.168.0.104
...
```

The `tests/` directory provides an additional example.


License
-------

GPL 3.0 or later.
