fence_ipmi_destroy
==================

This role removes an IPMI fencing resource from an existing Red Hat High Availability Add-On cluster.

You need to call that role once for each cluster node to delete the fence device for all the nodes.


Requirements
------------

The cluster must be running. See the `ha_create` role to create that cluster.


Role Variables
--------------

The role accepts the `fence_ipmi_destroy_id` variable to indicate the cluster resource name.
`fence_<short_hostname>` by default.


Dependencies
------------

None


Example Playbook
----------------

```yaml
---
- name: Deleting the fence device resources
  hosts: nodes
  become: yes
  gather_facts: no

  tasks:
    - include_role:
        name: fence_ipmi_destroy
      vars:
        fence_ipmi_destroy_id: "{{ item }}"
      loop:
        - fence_nodea
        - fence_nodeb
        - fence_nodec
        - fence_noded
...
```

The `tests/` directory provides an additional example.


License
-------

GPL 3.0 or later.
