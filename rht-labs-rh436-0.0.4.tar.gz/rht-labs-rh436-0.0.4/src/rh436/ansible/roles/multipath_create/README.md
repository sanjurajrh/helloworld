multipath_create
================

This role deploys and configures multipath.


Requirements
------------

None


Role Variables
--------------

The role accepts the `multipath_create_user_friendly_names` variable that specifies whether the multipath `user_friendly_names` parameter should be enabled or not.
See the `multipath.conf`(5) man page for more details.

By default, `multipath_create_user_friendly_names` is set to `no`.


Dependencies
------------

None


Example Playbook
----------------

```yaml
---
- name: Configuring multipath
  hosts: nodes
  become: yes
  gather_facts: no

  tasks:
    - include_role:
        name: multipath_create
      vars:
        multipath_create_user_friendly_names: yes
...
```

The `tests/` directory provides an additional example.


License
-------

GPL 3.0 or later.
