ha_destroy
==========

This role removes a Red Hat High Availability Add-On cluster from the remote nodes.


Requirements
------------

None


Role Variables
--------------

None


Dependencies
------------

None


Example Playbook
----------------

```yaml
---
- name: Destroying the cluster
  hosts: nodes
  become: yes
  gather_facts: no

  tasks:
    - include_role:
        name: ha_destroy
...
```

The `tests/` directory provides an additional example.



License
-------

GPL 3.0 or later.
