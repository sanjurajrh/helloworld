nfs_share_create
================

This role shares a directory using NFS.
The directory to share is provided using the `nfs_share_create_shared_dir` variable and is created if it does not exist.


Requirements
------------

None


Role Variables
--------------

The role accepts the following variables:

* `nfs_share_create_shared_dir`: The name of the directory to share. If it does not exist, it is created.
  `/srv/www` by default.
* `nfs_share_create_export_file`: The name of the export file. If it does not exist, it is created.
  `/etc/exports.d/share.exports` by default.
* `nfs_share_create_options`: The list of export options (see the `exports`(5) man page).
  `rw` and `no_root_squash` by default.
* `nfs_share_create_owner`: The owner of the directory. If this variable is defined, then the owner of the directory is set, otherwise, the directory owner is left unchanged.
  The variable is not set by default.
* `nfs_share_create_group`: The group owning the directory. If this variable is defined, then the group of the directory is set, otherwise, the directory group is left unchanged.
  The variable is not set by default.
* `nfs_share_create_mode`: The directory mode. If this variable is defined, then the mode of the directory is set, otherwise, the directory mode is left unchanged.
  The variable is not set by default.


Dependencies
------------

None


Example Playbook
----------------

```yaml
---
- name: Sharing the directory using NFS
  hosts: storage
  become: yes
  gather_facts: no

  tasks:
    - include_role:
        name: nfs_share_create
      vars:
        nfs_share_create_shared_dir: /srv/shared
        nfs_share_create_export_file: /etc/exports.d/shared.exports
        nfs_share_create_options:
          - ro
          - no_root_squash
        nfs_share_create_owner: student
        nfs_share_create_group: root
        nfs_share_create_mode: 0777
...
```

The `tests/` directory provides an additional example.


License
-------

GPL 3.0 or later.
