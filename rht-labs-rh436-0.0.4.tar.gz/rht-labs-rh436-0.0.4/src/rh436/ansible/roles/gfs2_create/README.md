gfs2_create
===========

This role prepares the cluster resources for hosting a GFS2 file system, creates the LVM volumes, and the format the GFS2 file system.
Optionally, the role can create the cluster resources to mount the new file system.


Requirements
------------

* The cluster must be running. See the `ha_create` role to create that cluster.
* A shared volume must be available on all the nodes. See the `iscsi_target_create`, `iscsi_initiator_create`, and optionally the `multipath_create` roles.


Role Variables
--------------

The role accepts the following variables:

* `gfs2_create_cluster_name`: The name of the cluster.
   `cluster1` by default.
* `gfs2_create_pv`: The block device to use as the physical volume. The device must be shared between all the nodes.
  `/dev/mapper/mpatha` by default.
* `gfs2_create_vg`: The name of the volume group to create.
  `sharedvg` by default.
* `gfs2_create_lv`: The name of the logical volume to create.
  `sharedlv1` by default.
* `gfs2_create_journals`:
   By default, the variable is set to the number of hosts in the play.
* `gfs2_create_size`: The size of the logical volume and file system in megabytes.
   Units in [kKmMgGtTpPeE] can be used.
  `5G` by default.
* `gfs2_create_mount`: Boolean instructing the role to create the cluster resources to automatically mount (`yes`) or not (`no`) the GFS2 file system.
  The variable is set to `yes` by default so that the role mounts the GFS2 file system.
* `gfs2_create_mount_point`: The mount point. Only used if `gfs2_create_mount` is `yes`. The roles creates the directory if it does not exist.
  `/srv/data` by default.


Dependencies
------------

None


Example Playbook
----------------

```yaml
---
- name: Creating a GFS2 file system in a two-nodes cluster
  hosts: nodea,nodeb
  become: yes
  gather_facts: no

  tasks:
    - include_role:
        name: gfs2_create
      vars:
        gfs2_create_vg: cluster_vg
        gfs2_create_lv: gfsdata
        gfs2_create_mount_point: /gfsdata
...
```

The `tests/` directory provides additional examples.


License
-------

GPL 3.0 or later.
