multipath_destroy
=================

This role removes multipath.


Requirements
------------

None


Role Variables
--------------

None


Dependencies
------------

None


Example Playbook
----------------

```yaml
---
- name: Removing multipath
  hosts: nodes
  become: yes
  gather_facts: no

  tasks:
    - include_role:
        name: multipath_destroy
...
```

The `tests/` directory provides an additional example.


License
-------

GPL 3.0 or later.
