preflight_checks
================

This role checks that the managed hosts are ready, and immediately fails the play otherwise.
You should call the role at the beginning of your play, before starting anything else.
For example, the role detects unreachable hosts, which is handy to prevent your play to run on a partial set of hosts.


Requirements
------------

None


Role Variables
--------------

None


Dependencies
------------

None


Example Playbook
----------------

```yaml
---
- name: Ensuring the managed hosts are ready
  hosts: nodes
  become: yes
  gather_facts: no

  tasks:
    - include_role:
        name: preflight_checks

    - name: Doing usefull stuff only when all the hosts are reachable
      yum:
        name: httpd
        state: present
...
```

The `tests/` directory provides an additional example.


License
-------

GPL 3.0 or later.
