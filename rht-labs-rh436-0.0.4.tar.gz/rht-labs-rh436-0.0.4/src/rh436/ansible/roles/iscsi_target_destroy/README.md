iscsi_target_destroy
====================

This role unconfigures an iSCSI target and wipes the associated disk.


Requirements
------------

Ansible Facts must be available (set `gather_facts` to `yes`)



Role Variables
--------------

The role accepts the `iscsi_target_destroy_disk` variable.
This is the name of the block device shared by iSCSI (without the `/dev/` part).
`vdb` by default.


Dependencies
------------

The `rhel-system-roles.storage` Linux system role must be available.
The `rhel-system-roles` RPM package, to install on the control node, provides that role.


Example Playbook
----------------

```yaml
---
- name: Unconfiguring the iSCSI target
  hosts: storage
  become: yes
  gather_facts: yes

  tasks:
    - include_role:
        name: iscsi_target_destroy
...
```

The `tests/` directory provides an additional example.


License
-------

GPL 3.0 or later.
