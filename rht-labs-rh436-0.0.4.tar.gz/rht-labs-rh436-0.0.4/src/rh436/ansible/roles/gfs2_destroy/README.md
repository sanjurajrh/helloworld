gfs2_destroy
============

This role removes a GFS2 file system from the cluster. The associated logical volume, volume group, and physical volume are wiped.


Requirements
------------

The cluster must be running. See the `ha_create` role to create that cluster.


Role Variables
--------------

The role accepts the following variables:

* `gfs2_destroy_pv`: The block device that is used as the physical volume.
  `/dev/mapper/mpatha` by default.
* `gfs2_destroy_vg`: The name of the volume group that hosts the GFS2 file system.
  `sharedvg` by default.
* `gfs2_destroy_lv`: The name of the logical volume that hosts the GFS2 file system.
  `sharedlv1` by default.
* `gfs2_destroy_mount`: Boolean specifying if the mount point defined by `gfs2_destroy_mount_point` must be removed.
  The variable is set to `yes` by default so that the mount point directory is deleted.
* `gfs2_destroy_mount_point`: The mount point. Only used if `gfs2_destroy_mount` is `yes`.
  `/srv/data` by default.


Dependencies
------------

None


Example Playbook
----------------

```yaml
---
- name: Removing a GFS2 file system from a two-nodes cluster
  hosts: nodea,nodeb
  become: yes
  gather_facts: no

  tasks:
    - include_role:
        name: gfs2_destroy
      vars:
        gfs2_destroy_vg: cluster_vg
        gfs2_destroy_lv: gfsdata
        gfs2_destroy_mount_point: /gfsdata
...
```

The `tests/` directory provides an additional example.


License
-------

GPL 3.0 or later.
